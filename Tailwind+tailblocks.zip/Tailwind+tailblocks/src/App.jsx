import React from 'react'
import Slider from './components/Slider'
import Navbar from './components/Navbar'
import { Route, Routes } from 'react-router-dom'
import Home from './components/Home'

const App = () => {
  return (
    <div >

    <Navbar/>
    <Routes>
    <Route path='/' element={<Home/>}></Route>
    <Route path='/slider' element={<Slider/>}></Route>
    
    </Routes>
    <Slider/>
    </div>
  )
}

export default App
